# RootCause-AI — OTel Evidence Reconciliation Testbed

A reproducible testbed for OpenTelemetry GenAI Semantic Conventions Issue #36.

## Cases
1. Direct Contradiction: agent success vs independently observed boundary failure.
2. No Independent Evidence: agent claim exists but no independent boundary observation exists.
3. Corroboration: agent success supported by a boundary observation; the external boundary is explicitly simulated.

## Provenance
Native runtime telemetry, simulated boundary evidence, and synthetic/post-processed ground truth are kept distinct. Simulated evidence is never presented as live external telemetry.
