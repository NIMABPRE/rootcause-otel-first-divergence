# Provenance

- Native runtime evidence: telemetry obtained from the OpenTelemetry SDK runtime.
- Simulated boundary evidence: explicitly marked test fixtures.
- Synthetic/post-processed ground truth: evaluation labels, not runtime observations.

No simulated boundary event should be interpreted as a live external-service observation.
