# Direct Contradiction

Agent/runtime claim: **success**  
Independent boundary observation: **error**  
Observation relationship: **contradictory**

Runtime telemetry and synthetic ground truth are kept separate.
